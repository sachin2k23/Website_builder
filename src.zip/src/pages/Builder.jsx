import { useState, useCallback, useRef, useEffect, useMemo } from 'react'
import CanvasTopbar from '../components/builder/CanvasTopbar'
import LeftPanel from '../components/builder/LeftPanel'
import Canvas from '../components/builder/Canvas'
import RightPanel from '../components/builder/RightPanel'
import InsertPanel from '../components/builder/InsertPanel'
import PreviewMode from '../components/builder/PreviewMode'
import ContextMenu from '../components/builder/ContextMenu'
import PageRenameModal from '../components/builder/PageRenameModal'
import ConfirmDialog from '../components/builder/ConfirmDialog'
import { exportToZip } from '../utils/exportHTML'
import { updateNode, deleteNode, findNode } from '../utils/treeHelpers'
import {
  applySmartResponsive,
  generateResponsiveDefaults,
  getElementLayout,
  getElementProperties,
  setBreakpointProps,
} from '../utils/responsive'
import { getContentHeight } from '../utils/editorGeometry'
import {
  applyThemeToTemplate,
  applyBoldSummitTheme,      // can keep or remove — no longer used directly
  getCanvasFillByTemplate,
  isTechSummitTemplate,
  isBoldSummitTemplate,
  isArtDecoTemplate,
  isNeuSummitTemplate,
  isVaporWaveFestTemplate,
  isMinimalistMonochromeTemplate,
  isFlatDesignTemplate,
  isBotanicalOrganicTemplate,
  isPlayfulGeometricTemplate,
  isAnyTemplate,             // ← ADD THIS
} from '../utils/templates'

const DEFAULT_SIZES = {
  heading:   { width: 320, height: 50  },
  paragraph: { width: 300, height: 80  },
  link:      { width: 120, height: 30  },
  container: { width: 320, height: 200 },
  section:   { width: 1200, height: 120 },
  divider:   { width: 400, height: 4   },
  image:     { width: 280, height: 180 },
  video:     { width: 320, height: 200 },
  button:    { width: 140, height: 44  },
  input:     { width: 260, height: 44  },
  textarea:  { width: 260, height: 100 },
  checkbox:  { width: 140, height: 30  },
  select:    { width: 200, height: 44  },
  label:     { width: 120, height: 24  },
  icon:      { width: 48,  height: 48  },
  card:      { width: 300, height: 200 },
}

const clamp = (value, min, max) => Math.min(Math.max(value, min), Math.max(min, max))

export default function Builder({
  onBack,
  initialElements = [],
  initialCanvasSettings = null,
  projectName = 'My Project',
  onProjectChange,
}) {

  // ── Modal states ───────────────────────────────────────────────────────────
  const [showRenamePageModal, setShowRenamePageModal] = useState(false)
  const [pageToRename, setPageToRename]               = useState(null)
  const [showDeletePageDialog, setShowDeletePageDialog] = useState(false)
  const [pageToDelete, setPageToDelete]               = useState(null)

  const [templateTheme, setTemplateTheme] = useState('light')
  // ── Pages ──────────────────────────────────────────────────────────────────
  const [pages, setPages]               = useState([{ id: 'home', name: 'Home' }])
  const [activePageId, setActivePageId] = useState('home')

  // ── Breakpoint ─────────────────────────────────────────────────────────────
  const [activeBreakpoint, setActiveBreakpoint] = useState('desktop')
  const [customWidth, setCustomWidth]           = useState(800)

  // ── Elements (tree) ────────────────────────────────────────────────────────
  const [treeByPage, setTreeByPage] = useState({
    home: initialElements.map(el => ({
      ...el,
      name:     el.name || el.type,
      children: [],
    }))
  })

  const tree     = useMemo(() => treeByPage[activePageId] || [], [treeByPage, activePageId])
  const elements = tree

  const setTree = useCallback((updater) => {
    setTreeByPage(prev => ({
      ...prev,
      [activePageId]:
        typeof updater === 'function'
          ? updater(prev[activePageId] || [])
          : updater,
    }))
  }, [activePageId])

  // ── Other state ────────────────────────────────────────────────────────────
  const [selectedId, setSelectedId]   = useState(null)
  const [showInsert, setShowInsert]   = useState(false)
  const [activeTab, setActiveTab]     = useState('Layers')
  const [isPreview, setIsPreview]     = useState(false)
  const [contextMenu, setContextMenu] = useState(null)
  const [canvasSettings, setCanvasSettings] = useState({
    width:  1200,
    height: 900,
    x:      0,
    y:      0,
    fill:   '#ffffff',
    ...(initialCanvasSettings || {}),
  })

  // ── History ────────────────────────────────────────────────────────────────
  const historyRef   = useRef([{ home: [] }])
  const historyIndex = useRef(0)
  const [historyTick, setHistoryTick] = useState(0)

  const pushSnapshot = useCallback((nextPageTree, prevTreeByPage) => {
    const snapshot = { ...prevTreeByPage, [activePageId]: nextPageTree }
    const trimmed  = historyRef.current.slice(0, historyIndex.current + 1)
    trimmed.push(snapshot)
    historyRef.current   = trimmed
    historyIndex.current = trimmed.length - 1
    setHistoryTick(tick => tick + 1)
    return snapshot
  }, [activePageId])

  // ── Selected element ───────────────────────────────────────────────────────
  const selectedElement = elements.find(el => el.id === selectedId) ?? null

  // ── Sync initialElements when template changes ─────────────────────────────
  useEffect(() => {
    const desktopCanvasWidth = canvasSettings?.width || 1200

    const prepared = initialElements.map(el => ({
      ...el,
      name:     el.name || el.type,
      children: [],
    }))

    const normalized = prepared.map(el => {
      if (el.desktop && typeof el.desktop === 'object') return el
      return applySmartResponsive([el], desktopCanvasWidth)[0]
    })

    // Apply the correct default theme for every template type on load.
    // Each template's defaultTheme is respected: dark templates start dark,
    // light templates start light. applyThemeToTemplate dispatches correctly.
    const templateDefaultTheme = (() => {
      if (isTechSummitTemplate(normalized))    return 'dark'
      if (isVaporWaveFestTemplate(normalized)) return 'dark'
      // all other templates default to light
      return 'light'
    })()
    
    setTemplateTheme(templateDefaultTheme) 
 
    const mapped = isAnyTemplate(normalized)
      ? applyThemeToTemplate(normalized, templateDefaultTheme)
      : normalized

    setCanvasSettings(prev => ({
      ...prev,
      ...(initialCanvasSettings || {}),
      fill: initialCanvasSettings?.fill ?? getCanvasFillByTemplate(mapped, templateDefaultTheme),
      height: initialCanvasSettings?.height || getContentHeight(mapped, 'desktop', 900),
    }))
    setTreeByPage(prev => ({ ...prev, [activePageId]: mapped }))
    setSelectedId(null)
    historyRef.current   = [{ [activePageId]: mapped }]
    historyIndex.current = 0
    setHistoryTick(tick => tick + 1)
  }, [initialElements, initialCanvasSettings]) // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    onProjectChange?.({
      name: projectName,
      elements,
      canvasSettings,
    })
  }, [elements, canvasSettings, projectName, onProjectChange])

  // ── Breakpoint switch ──────────────────────────────────────────────────────
const handleBreakpointChange = useCallback((bp) => {
  setActiveBreakpoint(bp)
  setSelectedId(null)
  // Never re-run applySmartResponsive or generateResponsiveDefaults on switch.
  // Elements already have all breakpoint buckets from when they were created.
  // Re-running here overwrites any edits the user made in that breakpoint.
}, [])

  // ── Shared: commit new node(s) to tree + history ───────────────────────────
  const commitNodes = useCallback((newNodes) => {
    setTreeByPage(prev => {
      const current = prev[activePageId] || []
      const next    = [...current, ...newNodes]
      return pushSnapshot(next, prev)
    })
    setSelectedId(newNodes[newNodes.length - 1]?.id ?? null)
  }, [activePageId, pushSnapshot])

  // ── Click-to-insert ────────────────────────────────────────────────────────
  const handleInsert = useCallback((el) => {
    const sizes              = DEFAULT_SIZES[el.id] || { width: 200, height: 100 }
    const desktopCanvasWidth = canvasSettings?.width || 1200

    if (el.type === 'group') {
      const baseTime = Date.now()
      const newNodes = (el.children || []).map((child, index) =>
        generateResponsiveDefaults({
          ...child,
          id:       `${baseTime + index}`,
          type:     child.type || child.id,
          name:     child.name || child.label || child.type || child.id,
          children: child.children || [],
        }, desktopCanvasWidth)
      )
      if (!newNodes.length) return
      commitNodes(newNodes)
      return
    }

    const newNode = generateResponsiveDefaults({
      content:     '',
      fill:        '#ffffff',
      borderColor: null,
      shadowColor: null,
      radius:      0,
      opacity:     100,
      textColor:   '#111827',
      children:    [],
      ...el,
      id:     Date.now().toString(),
      type:   el.type || el.id,
      name:   el.name || el.label,
      x:      el.x    ?? 80,
      y:      el.y    ?? 80,
      width:  el.width  ?? sizes.width,
      height: el.height ?? sizes.height,
    }, desktopCanvasWidth)

    if (selectedId) {
      const selected    = findNode(tree, selectedId)
      const isContainer = selected?.type === 'container' || selected?.type === 'section' || selected?.type === 'frame'
      if (isContainer) {
        setTree(prev => updateNode(prev, selectedId, { children: [...(selected.children || []), newNode] }))
        setSelectedId(newNode.id)
        return
      }
    }

    commitNodes([newNode])
  }, [tree, selectedId, canvasSettings, commitNodes, setTree])

  // ── Drag-to-canvas insert ──────────────────────────────────────────────────
  const handleDropInsert = useCallback((el, dropX, dropY) => {
    const sizes              = DEFAULT_SIZES[el.id] || { width: 200, height: 100 }
    const desktopCanvasWidth = canvasSettings?.width || 1200
    const canvasHeight       = canvasSettings?.height || 900

    if (el.type === 'group') {
      const baseTime = Date.now()
      const newNodes = (el.children || []).map((child, index) =>
        generateResponsiveDefaults({
          ...child,
          id:       `${baseTime + index}`,
          type:     child.type || child.id,
          name:     child.name || child.label || child.type || child.id,
          x:        Math.max(0, (child.x ?? 0) + dropX),
          y:        Math.max(0, (child.y ?? 0) + dropY),
          children: child.children || [],
        }, desktopCanvasWidth)
      )
      if (!newNodes.length) return
      commitNodes(newNodes)
      return
    }

    const elWidth  = el.width  ?? sizes.width
    const elHeight = el.height ?? sizes.height

    const newNode = generateResponsiveDefaults({
      content:     '',
      fill:        '#ffffff',
      borderColor: null,
      shadowColor: null,
      radius:      0,
      opacity:     100,
      textColor:   '#111827',
      children:    [],
      ...el,
      id:     Date.now().toString(),
      type:   el.type || el.id,
      name:   el.name || el.label,
      x:      clamp(dropX - Math.round(elWidth  / 2), 0, desktopCanvasWidth - elWidth),
      y:      clamp(dropY - Math.round(elHeight / 2), 0, canvasHeight - elHeight),
      width:  elWidth,
      height: elHeight,
    }, desktopCanvasWidth)

    commitNodes([newNode])
  }, [canvasSettings, commitNodes])

  // ── Delete ─────────────────────────────────────────────────────────────────
  const handleDelete = useCallback((id) => {
    setTreeByPage(prev => {
      const current = prev[activePageId] || []
      const next    = deleteNode(current, id)
      return pushSnapshot(next, prev)
    })
    setSelectedId(null)
  }, [activePageId, pushSnapshot])

  // ── Update ─────────────────────────────────────────────────────────────────
  const handleUpdate = useCallback((id, changes, options = {}) => {

    const applyUpdate = (currentTree) => {
      // Global: write to element root (content, baselines, src, name, etc.)
      if (options.global) {
        return currentTree.map(el => {
          if (el.id !== id) return el
          return { ...el, ...changes }
        })
      }

      // Default: write ONLY to the active breakpoint bucket
      return currentTree.map(el => {
        if (el.id !== id) return el
        return setBreakpointProps(el, activeBreakpoint, changes)
      })
    }

    if (options.commit) {
      setTreeByPage(prev => {
        const current = prev[activePageId] || []
        return pushSnapshot(applyUpdate(current), prev)
      })
      return
    }

    setTree(prev => applyUpdate(prev))
  }, [setTree, setTreeByPage, activeBreakpoint, activePageId, pushSnapshot])

  // ── Canvas update ──────────────────────────────────────────────────────────
  const handleCanvasUpdate = useCallback((changes) => {
    setCanvasSettings(prev => ({ ...prev, ...changes }))
  }, [])

  // ── Template theme toggle ──────────────────────────────────────────────────
const handleTemplateThemeToggle = useCallback(() => {
  const current    = treeByPage[activePageId] || []
  if (!isAnyTemplate(current)) return

  const nextTheme = templateTheme === 'light' ? 'dark' : 'light'
  const nextFill  = getCanvasFillByTemplate(current, nextTheme)
  if (nextFill) setCanvasSettings(prev => ({ ...prev, fill: nextFill }))
  setTemplateTheme(nextTheme)
  setTreeByPage(prev => {
    const currentTree = prev[activePageId] || []
    return pushSnapshot(applyThemeToTemplate(currentTree, nextTheme), prev)
  })
}, [activePageId, pushSnapshot, treeByPage, templateTheme])

  // ── Undo / Redo ────────────────────────────────────────────────────────────
  const undo = useCallback(() => {
    if (historyIndex.current <= 0) return
    historyIndex.current--
    setTreeByPage(historyRef.current[historyIndex.current])
    setSelectedId(null)
    setHistoryTick(tick => tick + 1)
  }, [])

  const redo = useCallback(() => {
    if (historyIndex.current >= historyRef.current.length - 1) return
    historyIndex.current++
    setTreeByPage(historyRef.current[historyIndex.current])
    setSelectedId(null)
    setHistoryTick(tick => tick + 1)
  }, [])

  // ── Duplicate ──────────────────────────────────────────────────────────────
  const handleDuplicate = useCallback((id) => {
    const el = elements.find(el => el.id === id)
    if (!el) return
    const desktopCanvasWidth = canvasSettings?.width || 1200
    const layout = getElementLayout(el, activeBreakpoint)
    const newEl  = generateResponsiveDefaults({
      ...el,
      id: Date.now().toString(),
      x:  layout.x + 20,
      y:  layout.y + 20,
    }, desktopCanvasWidth)
    commitNodes([newEl])
  }, [elements, activeBreakpoint, canvasSettings, commitNodes])

  // ── Reorder ────────────────────────────────────────────────────────────────
  const handleReorder = useCallback((id, direction) => {
    setTreeByPage(prev => {
      const current = prev[activePageId] || []
      const index   = current.findIndex(el => el.id === id)
      if (index === -1) return prev
      const next = [...current]
      if (direction === 'forward'  && index < next.length - 1) [next[index], next[index + 1]] = [next[index + 1], next[index]]
      if (direction === 'back'     && index > 0)               [next[index], next[index - 1]] = [next[index - 1], next[index]]
      if (direction === 'front')   { const [el] = next.splice(index, 1); next.push(el) }
      if (direction === 'back-all'){ const [el] = next.splice(index, 1); next.unshift(el) }
      return pushSnapshot(next, prev)
    })
  }, [activePageId, pushSnapshot])

  // ── Page management ────────────────────────────────────────────────────────
  const handleAddPage = useCallback((pageData) => {
    const { id, name, slug } = pageData
    setPages(prev => [...prev, { id, name, slug }])
    setTreeByPage(prev => ({ ...prev, [id]: [] }))
    setActivePageId(id)
    setSelectedId(null)
  }, [])

  const handleRenamePage = (id) => {
    const page = pages.find(p => p.id === id)
    setPageToRename(page)
    setShowRenamePageModal(true)
  }

  const handleRenamePageConfirm = (newName) => {
    if (!pageToRename) return
    setPages(prev => prev.map(p => p.id === pageToRename.id ? { ...p, name: newName } : p))
    setPageToRename(null)
  }

  const handleDeletePage = (id) => {
    if (pages.length === 1) {
      alert('Cannot delete the last page')
      return
    }
    setPageToDelete(id)
    setShowDeletePageDialog(true)
  }

  const handleDeletePageConfirm = () => {
    if (!pageToDelete) return
    setPages(prev => prev.filter(p => p.id !== pageToDelete))
    setTreeByPage(prev => { const next = { ...prev }; delete next[pageToDelete]; return next })
    setActivePageId(pages.filter(p => p.id !== pageToDelete)[0].id)
    setSelectedId(null)
    setPageToDelete(null)
  }

  const handleSwitchPage = (id) => {
    setActivePageId(id)
    setSelectedId(null)
  }

  const handleUpdatePage = (id, changes) => {
    setPages(prev => prev.map(p => p.id === id ? { ...p, ...changes } : p))
  }

  // ── Keyboard shortcuts ─────────────────────────────────────────────────────
  useEffect(() => {
    const onKeyDown = (e) => {
      const active = document.activeElement
      if (active?.tagName === 'INPUT' || active?.isContentEditable) return

      if ((e.metaKey || e.ctrlKey) && e.key === 'z' && !e.shiftKey) { e.preventDefault(); undo(); return }
      if ((e.metaKey || e.ctrlKey) && (e.key === 'y' || (e.key === 'z' && e.shiftKey))) { e.preventDefault(); redo(); return }
      if (e.key === 'Escape') { setSelectedId(null); return }
      if (!selectedId) return

      if (e.key === 'Delete' || e.key === 'Backspace') { handleDelete(selectedId); return }
      if ((e.metaKey || e.ctrlKey) && e.key === 'd') { e.preventDefault(); handleDuplicate(selectedId); return }

      if (['ArrowUp', 'ArrowDown', 'ArrowLeft', 'ArrowRight'].includes(e.key)) {
        e.preventDefault()
        const step   = e.shiftKey ? 10 : 1
        const el     = elements.find(el => el.id === selectedId)
        if (!el) return
        const layout = getElementLayout(el, activeBreakpoint)
        const delta  = {
          ArrowUp:    { y: layout.y - step },
          ArrowDown:  { y: layout.y + step },
          ArrowLeft:  { x: layout.x - step },
          ArrowRight: { x: layout.x + step },
        }[e.key]
        handleUpdate(selectedId, delta)
      }
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [selectedId, elements, undo, redo, handleDelete, handleDuplicate, handleUpdate, activeBreakpoint])

  // ── Close context menu ─────────────────────────────────────────────────────
  useEffect(() => {
    const close = () => setContextMenu(null)
    window.addEventListener('click', close)
    return () => window.removeEventListener('click', close)
  }, [])

  // ── Resolve selected element props for RightPanel (breakpoint-aware) ───────
  const selectedForPanel = selectedElement
    ? { ...selectedElement, ...getElementProperties(selectedElement, activeBreakpoint) }
    : null

  // ── Render ─────────────────────────────────────────────────────────────────
  return (
    <div className="flex flex-col h-screen w-screen overflow-hidden bg-[#F0F2F8]">
      {isPreview ? (
        <PreviewMode
          pages={pages}
          treeByPage={treeByPage}
          activePageId={activePageId}
          canvasSettings={canvasSettings}
          onExit={() => setIsPreview(false)}
        />
      ) : (
        <>
          <CanvasTopbar
              onBack={onBack}
              projectName={projectName}
              onInsertClick={() => setShowInsert(v => !v)}
              onUndo={undo}
              onRedo={redo}
              canUndo={historyIndex.current > 0}
              canRedo={historyIndex.current < historyRef.current.length - 1}
              historyTick={historyTick}
              onPreview={() => setIsPreview(true)}
              onExport={async () => await exportToZip(elements, canvasSettings, projectName)}
              templateTheme={templateTheme}                      
              onTemplateThemeToggle={handleTemplateThemeToggle}    
            />

          <div className="flex flex-1 overflow-hidden relative">

            <div className="relative hidden shrink-0 lg:flex">
              <LeftPanel
                elements={elements}
                selectedId={selectedId}
                onSelect={setSelectedId}
                activeTab={activeTab}
                onTabChange={setActiveTab}
                pages={pages}
                activePageId={activePageId}
                onSwitchPage={handleSwitchPage}
                onAddPage={handleAddPage}
                onRenamePage={handleRenamePage}
                onDeletePage={handleDeletePage}
                onUpdatePage={handleUpdatePage}
              />
            </div>

            {showInsert && (
              <div className="absolute inset-y-0 left-0 z-40 flex max-w-[100vw] border-r border-[#D8E1F0] bg-white shadow-xl lg:static">
                <InsertPanel onInsert={handleInsert} />
              </div>
            )}

            <Canvas
              elements={elements}
              selectedId={selectedId}
              onSelect={(id) => { setSelectedId(id); setShowInsert(false) }}
              onDelete={handleDelete}
              onUpdate={handleUpdate}
              canvasSettings={canvasSettings}
              onContextMenu={(e, id) => {
                e.preventDefault()
                setContextMenu({ x: e.clientX, y: e.clientY, elementId: id })
                setSelectedId(id)
              }}
              activeBreakpoint={activeBreakpoint}
              onBreakpointChange={handleBreakpointChange}
              customWidth={customWidth}
              onCustomWidthChange={setCustomWidth}
              onDropInsert={handleDropInsert}
            />

            <div className="hidden xl:flex">
              <RightPanel
                key={selectedId}
                selected={selectedForPanel}
                elements={elements}
                pages={pages}
                onUpdate={handleUpdate}
                canvasSettings={canvasSettings}
                onCanvasUpdate={handleCanvasUpdate}
                onDelete={handleDelete}
                onDuplicate={handleDuplicate}
                onReorder={handleReorder}
                activeBreakpoint={activeBreakpoint}
                customWidth={customWidth}
              />
            </div>
          </div>
        </>
      )}

      {contextMenu && (
        <ContextMenu
          x={contextMenu.x}
          y={contextMenu.y}
          elementId={contextMenu.elementId}
          onReorder={handleReorder}
          onDuplicate={handleDuplicate}
          onDelete={handleDelete}
          onClose={() => setContextMenu(null)}
        />
      )}

      {showRenamePageModal && pageToRename && (
        <PageRenameModal
          page={pageToRename}
          onConfirm={handleRenamePageConfirm}
          onClose={() => { setShowRenamePageModal(false); setPageToRename(null) }}
        />
      )}
      

      {showDeletePageDialog && (
        <ConfirmDialog
          title="Delete Page?"
          message="Are you sure you want to delete this page? This cannot be undone."
          onConfirm={() => { handleDeletePageConfirm(); setShowDeletePageDialog(false) }}
          onClose={() => { setShowDeletePageDialog(false); setPageToDelete(null) }}
        />
      )}
    </div>
  )
}